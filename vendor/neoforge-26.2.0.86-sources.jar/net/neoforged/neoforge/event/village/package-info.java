/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

@NullMarked
package net.neoforged.neoforge.event.village;

import org.jspecify.annotations.NullMarked;
